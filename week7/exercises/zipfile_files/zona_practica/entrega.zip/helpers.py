def ayudar(): pass
