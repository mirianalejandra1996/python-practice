print("main")
